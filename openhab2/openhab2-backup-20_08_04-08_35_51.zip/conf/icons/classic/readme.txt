Your additional icons go here.
Icons can be provided as png (32x32) or preferably as svg files.
ClassicUI and BasicUI can be configured to accept svg (default) or png icons.

Check out the openHAB documentation for more details:
https://www.openhab.org/docs/configuration/items.html#icons
